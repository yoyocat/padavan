package aghhttp

// HTTP headers

// HTTP header value constants.
const (
	HdrValApplicationJSON = "application/json"
	HdrValTextPlain       = "text/plain"
)
