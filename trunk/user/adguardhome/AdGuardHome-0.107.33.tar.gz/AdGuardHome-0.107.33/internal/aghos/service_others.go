//go:build !darwin

package aghos

// preCheckActionStart performs the service start action pre-check.
func preCheckActionStart() (err error) {
	return nil
}
