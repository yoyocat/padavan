package aghos

// PreCheckActionStart performs the service start action pre-check.
func PreCheckActionStart() (err error) {
	return preCheckActionStart()
}
